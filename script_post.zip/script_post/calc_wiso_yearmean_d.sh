
#
# **** calc_wiso_yearmean_d ****
#
# Script calcutates the yearly mean delta values of several monthly mean water flux and surface reservoir fields
#
# The idividual monthly means should have been calculated using the calc_wiso_monmean_d.e4 script.
#
# The yearly mean delta values are prec.weighted mean values, based on the given monthly precipitation amounts.
#
# externals: cdo-Routines by U.Schulzweida (MPI MET, Hamburg)
#
IN=$1
OUT=$2
SMOW=$3
TBL=$4
cdo=cdo
#
#
$cdo -f nc -selvar,temp2      ${IN} temp2
$cdo -f nc -selvar,tsurf      ${IN} tsurf
$cdo -f nc -selvar,aprt       ${IN} aprt
$cdo -f nc -selvar,aprl       ${IN} aprl
$cdo -f nc -selvar,aprc       ${IN} aprc
$cdo -f nc -selvar,aprs       ${IN} aprs
$cdo -f nc -selvar,evap       ${IN} evap
$cdo -f nc -selvar,pe         ${IN} pe
$cdo -f nc -selvar,ws         ${IN} ws
$cdo -f nc -selvar,sn         ${IN} sn
$cdo -f nc -selvar,runoff     ${IN} runoff
$cdo -f nc -selvar,wisoaprt   ${IN} wisoaprt
$cdo -f nc -selvar,wisoaprl   ${IN} wisoaprl
$cdo -f nc -selvar,wisoaprc   ${IN} wisoaprc
$cdo -f nc -selvar,wisoaprs   ${IN} wisoaprs
$cdo -f nc -selvar,wisoevap   ${IN} wisoevap
$cdo -f nc -selvar,wisope     ${IN} wisope
$cdo -f nc -selvar,wisows     ${IN} wisows
$cdo -f nc -selvar,wisosn     ${IN} wisosn
$cdo -f nc -selvar,wisorunoff ${IN} wisorunoff
#
#
# calculate default yearly mean value of standard ECHAM fields
#
$cdo -f nc yearmean temp2      temp2.yearmean
$cdo -f nc yearmean tsurf      tsurf.yearmean
$cdo -f nc yearmean aprt       aprt.yearmean
$cdo -f nc yearmean aprl       aprl.yearmean
$cdo -f nc yearmean aprc       aprc.yearmean
$cdo -f nc yearmean aprs       aprs.yearmean
$cdo -f nc yearmean evap       evap.yearmean
$cdo -f nc yearmean pe         pe.yearmean
$cdo -f nc yearmean ws         ws.yearmean
$cdo -f nc yearmean sn         sn.yearmean
$cdo -f nc yearmean runoff     runoff.yearmean
$cdo -f nc yearmean wisoaprt   wisoaprt.yearmean
$cdo -f nc yearmean wisoaprl   wisoaprl.yearmean
$cdo -f nc yearmean wisoaprc   wisoaprc.yearmean
$cdo -f nc yearmean wisoaprs   wisoaprs.yearmean
$cdo -f nc yearmean wisoevap   wisoevap.yearmean
$cdo -f nc yearmean wisope     wisope.yearmean
$cdo -f nc yearmean wisows     wisows.yearmean
$cdo -f nc yearmean wisosn     wisosn.yearmean
$cdo -f nc yearmean wisorunoff wisorunoff.yearmean
#
#
# calcultate a precipitation-weighted yearly mean delta value according to the formula:
#
#      delta_mean = sum (prec_wiso_i) / sum (prec_i)
#
$cdo -s -f nc -chvar,wisoaprt,wisoaprt_d     -chcode,50,10 -mulc,1000. -subc,1. -div -div -yearsum wisoaprt   -yearsum aprt   ${SMOW} wisoaprt_d.yearmean
$cdo -s -f nc -chvar,wisoaprl,wisoaprl_d     -chcode,53,13 -mulc,1000. -subc,1. -div -div -yearsum wisoaprl   -yearsum aprl   ${SMOW} wisoaprl_d.yearmean
$cdo -s -f nc -chvar,wisoaprc,wisoaprc_d     -chcode,54,14 -mulc,1000. -subc,1. -div -div -yearsum wisoaprc   -yearsum aprc   ${SMOW} wisoaprc_d.yearmean
$cdo -s -f nc -chvar,wisoaprs,wisoaprs_d     -chcode,55,15 -mulc,1000. -subc,1. -div -div -yearsum wisoaprs   -yearsum aprs   ${SMOW} wisoaprs_d.yearmean
$cdo -s -f nc -chvar,wisoevap,wisoevap_d     -chcode,59,19 -mulc,1000. -subc,1. -div -div -yearsum wisoevap   -yearsum evap   ${SMOW} wisoevap_d.yearmean
$cdo -s -f nc -chvar,wisope,wisope_d         -chcode,60,20 -mulc,1000. -subc,1. -div -div -yearsum wisope     -yearsum pe     ${SMOW} wisope_d.yearmean
$cdo -s -f nc -chvar,wisows,wisows_d         -chcode,51,11 -mulc,1000. -subc,1. -div -div -yearsum wisows     -yearsum ws     ${SMOW} wisows_d.yearmean
$cdo -s -f nc -chvar,wisosn,wisosn_d         -chcode,52,12 -mulc,1000. -subc,1. -div -div -yearsum wisosn     -yearsum sn     ${SMOW} wisosn_d.yearmean
$cdo -s -f nc -chvar,wisorunoff,wisorunoff_d -chcode,57,17 -mulc,1000. -subc,1. -div -div -yearsum wisorunoff -yearsum runoff ${SMOW} wisorunoff_d.yearmean
#
#
# merge all fields together
#
$cdo -f nc -t ${TBL} merge \
   wisoaprt_d.yearmean wisoaprl_d.yearmean wisoaprc_d.yearmean wisoaprs_d.yearmean wisoevap_d.yearmean wisope_d.yearmean wisows_d.yearmean wisosn_d.yearmean wisorunoff_d.yearmean \
     wisoaprt.yearmean   wisoaprl.yearmean   wisoaprc.yearmean   wisoaprs.yearmean   wisoevap.yearmean   wisope.yearmean   wisows.yearmean   wisosn.yearmean   wisorunoff.yearmean \
         aprt.yearmean       aprl.yearmean       aprc.yearmean       aprs.yearmean       evap.yearmean       pe.yearmean       ws.yearmean       sn.yearmean       runoff.yearmean \
   temp2.yearmean tsurf.yearmean $OUT
#
#
# clean up
#
rm wisoaprt_d.yearmean wisoaprl_d.yearmean wisoaprc_d.yearmean wisoaprs_d.yearmean wisoevap_d.yearmean wisope_d.yearmean wisows_d.yearmean wisosn_d.yearmean wisorunoff_d.yearmean
rm   wisoaprt.yearmean   wisoaprl.yearmean   wisoaprc.yearmean   wisoaprs.yearmean   wisoevap.yearmean   wisope.yearmean   wisows.yearmean   wisosn.yearmean   wisorunoff.yearmean 
rm       aprt.yearmean       aprl.yearmean       aprc.yearmean       aprs.yearmean       evap.yearmean       pe.yearmean       ws.yearmean       sn.yearmean       runoff.yearmean
rm temp2.yearmean tsurf.yearmean
#
rm wisoaprt wisoaprl wisoaprc wisoaprs wisoevap wisope wisows wisosn wisorunoff
rm     aprt     aprl     aprc     aprs     evap     pe     ws     sn     runoff
rm temp2 tsurf
#
echo " "
echo "**** DONE. ****"
echo " "
#
exit
