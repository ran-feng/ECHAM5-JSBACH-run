
#
# **** calc_wiso_timmean_d ****
#
# Script calcutates the long-time mean delta values of several monthly mean water flux and surface reservoir fields
#
# The idividual monthly means should have been calculated using the calc_wiso_monmean_d script.
#
# The long-time mean delta values are prec.weighted mean values, based on the given monthly precipitation amounts.
#
# externals: cdo-Routines by U.Schulzweida (MPI MET, Hamburg)
#
IN=${1}
OUT=${2}
SMOW=${3}
TBL=${4}
#IN=WISO_1991hlf.nc
#OUT=WISO2.3_1991hlf.nc
cdo=cdo
#
#
$cdo -f nc -selvar,temp2      ${IN} temp2
$cdo -f nc -selvar,tsurf      ${IN} tsurf
$cdo -f nc -selvar,aprt       ${IN} aprt
$cdo -f nc -selvar,aprl       ${IN} aprl
$cdo -f nc -selvar,aprc       ${IN} aprc
$cdo -f nc -selvar,aprs       ${IN} aprs
$cdo -f nc -selvar,evap       ${IN} evap
$cdo -f nc -selvar,pe         ${IN} pe
$cdo -f nc -selvar,ws         ${IN} ws
$cdo -f nc -selvar,sn         ${IN} sn
$cdo -f nc -selvar,runoff     ${IN} runoff
$cdo -f nc -selvar,wisoaprt   ${IN} wisoaprt
$cdo -f nc -selvar,wisoaprl   ${IN} wisoaprl
$cdo -f nc -selvar,wisoaprc   ${IN} wisoaprc
$cdo -f nc -selvar,wisoaprs   ${IN} wisoaprs
$cdo -f nc -selvar,wisoevap   ${IN} wisoevap
$cdo -f nc -selvar,wisope     ${IN} wisope
$cdo -f nc -selvar,wisows     ${IN} wisows
$cdo -f nc -selvar,wisosn     ${IN} wisosn
$cdo -f nc -selvar,wisorunoff ${IN} wisorunoff
#
#
# calculate default long-time mean value of standard ECHAM fields
#
$cdo -f nc timmean temp2      temp2.timmean
$cdo -f nc timmean tsurf      tsurf.timmean
$cdo -f nc timmean aprt       aprt.timmean
$cdo -f nc timmean aprl       aprl.timmean
$cdo -f nc timmean aprc       aprc.timmean
$cdo -f nc timmean aprs       aprs.timmean
$cdo -f nc timmean evap       evap.timmean
$cdo -f nc timmean pe         pe.timmean
$cdo -f nc timmean ws         ws.timmean
$cdo -f nc timmean sn         sn.timmean
$cdo -f nc timmean runoff     runoff.timmean
$cdo -f nc timmean wisoaprt   wisoaprt.timmean
$cdo -f nc timmean wisoaprl   wisoaprl.timmean
$cdo -f nc timmean wisoaprc   wisoaprc.timmean
$cdo -f nc timmean wisoaprs   wisoaprs.timmean
$cdo -f nc timmean wisoevap   wisoevap.timmean
$cdo -f nc timmean wisope     wisope.timmean
$cdo -f nc timmean wisows     wisows.timmean
$cdo -f nc timmean wisosn     wisosn.timmean
$cdo -f nc timmean wisorunoff wisorunoff.timmean
#
#
# calcultate a precipitation-weighted long-time mean delta value according to the formula:
#
#      delta_mean = sum (prec_wiso_i) / sum (prec_i)
#
$cdo -s -f nc -chvar,wisoaprt,wisoaprt_d     -chcode,50,10 -mulc,1000. -subc,1. -div -div -timsum wisoaprt   -timsum aprt   ${SMOW} wisoaprt_d.timmean
$cdo -s -f nc -chvar,wisoaprl,wisoaprl_d     -chcode,53,13 -mulc,1000. -subc,1. -div -div -timsum wisoaprl   -timsum aprl   ${SMOW} wisoaprl_d.timmean
$cdo -s -f nc -chvar,wisoaprc,wisoaprc_d     -chcode,54,14 -mulc,1000. -subc,1. -div -div -timsum wisoaprc   -timsum aprc   ${SMOW} wisoaprc_d.timmean
$cdo -s -f nc -chvar,wisoaprs,wisoaprs_d     -chcode,55,15 -mulc,1000. -subc,1. -div -div -timsum wisoaprs   -timsum aprs   ${SMOW} wisoaprs_d.timmean
$cdo -s -f nc -chvar,wisoevap,wisoevap_d     -chcode,59,19 -mulc,1000. -subc,1. -div -div -timsum wisoevap   -timsum evap   ${SMOW} wisoevap_d.timmean
$cdo -s -f nc -chvar,wisope,wisope_d         -chcode,60,20 -mulc,1000. -subc,1. -div -div -timsum wisope     -timsum pe     ${SMOW} wisope_d.timmean
$cdo -s -f nc -chvar,wisows,wisows_d         -chcode,51,11 -mulc,1000. -subc,1. -div -div -timsum wisows     -timsum ws     ${SMOW} wisows_d.timmean
$cdo -s -f nc -chvar,wisosn,wisosn_d         -chcode,52,12 -mulc,1000. -subc,1. -div -div -timsum wisosn     -timsum sn     ${SMOW} wisosn_d.timmean
$cdo -s -f nc -chvar,wisorunoff,wisorunoff_d -chcode,57,17 -mulc,1000. -subc,1. -div -div -timsum wisorunoff -timsum runoff ${SMOW} wisorunoff_d.timmean
#
#
# merge all fields together
#
$cdo -f nc -t ${TBL} merge \
   wisoaprt_d.timmean wisoaprl_d.timmean wisoaprc_d.timmean wisoaprs_d.timmean wisoevap_d.timmean wisope_d.timmean wisows_d.timmean wisosn_d.timmean wisorunoff_d.timmean \
     wisoaprt.timmean   wisoaprl.timmean   wisoaprc.timmean   wisoaprs.timmean   wisoevap.timmean   wisope.timmean   wisows.timmean   wisosn.timmean   wisorunoff.timmean \
         aprt.timmean       aprl.timmean       aprc.timmean       aprs.timmean       evap.timmean       pe.timmean       ws.timmean       sn.timmean       runoff.timmean \
   temp2.timmean tsurf.timmean $OUT
#
#
# clean up
#
rm wisoaprt_d.timmean wisoaprl_d.timmean wisoaprc_d.timmean wisoaprs_d.timmean wisoevap_d.timmean wisope_d.timmean wisows_d.timmean wisosn_d.timmean wisorunoff_d.timmean
rm   wisoaprt.timmean   wisoaprl.timmean   wisoaprc.timmean   wisoaprs.timmean   wisoevap.timmean   wisope.timmean   wisows.timmean   wisosn.timmean   wisorunoff.timmean 
rm       aprt.timmean       aprl.timmean       aprc.timmean       aprs.timmean       evap.timmean       pe.timmean       ws.timmean       sn.timmean       runoff.timmean
rm temp2.timmean tsurf.timmean
#
rm wisoaprt wisoaprl wisoaprc wisoaprs wisoevap wisope wisows wisosn wisorunoff
rm     aprt     aprl     aprc     aprs     evap     pe     ws     sn     runoff
rm temp2 tsurf
#
echo " "
echo "**** DONE. ****"
echo " "
#
exit
