#! /bin/ksh -fx
#
# **** calc_wiso_monmean_d ****
#
# Script calculates monthly mean delta values of several water isotope fields for ECHAM5-wiso data
#
# externals: cdo-Routines by U.Schulzweida (MPI MET, Hamburg)
#
#
IN=${1}
INWISO=${2}
OUT=${3}
TBL=${4}
SMOW=${5}

#IN=../../cntl_as/cntl_as_199101.01.nc
#INWISO=../../cntl_as/cntl_as_199101.01_wiso.nc
#OUT=./WISO_199101.nc
#TBL=./CODES.WISO
#SMOW=./SMOW.FAC.T63L19.nc
CDO=cdo
#
#
echo " "
echo "*** CALCULATE MONTHLY MEANS OF FILE: "$IN" ***"
echo " "
#
# get the following standard ECHAM water fluxes and resevoirs:
# large scale precip., convective precip., snow fall, evaporation, runoff, soil wetness, snow depth 
#
echo "Get ECHAM default fields"
echo " "
#
# convert  precipitation, evaporation and runoff fields from kg/m**2s to mm/month
# (conversion factor: 3600*24*365/12*1000/1000 = 2.628e6)
#
# convert 2m-temperature and surface temperature from K to C)
#
$CDO -s -f nc -monmean -subc,273.15  -selcode,167 $IN temp2
$CDO -s -f nc -monmean -subc,273.15  -selcode,169 $IN tsurf
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,142 $IN aprl
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,143 $IN aprc
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,144 $IN aprs
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,182 $IN evap
$CDO -s -f nc -monmean               -selcode,140 $IN ws
$CDO -s -f nc -monmean               -selcode,141 $IN sn
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,160 $IN runoff
#
# calculate total precipitation
$CDO -s -f nc -chvar,aprl,aprt -chcode,142,260 -add aprl aprc aprt
#
# calculate total precipitation - evaporation 
$CDO -s -f nc -chvar,aprt,pe -chcode,260,265 -add aprt evap pe
#
#
# get related water isotope fields and reservoirs
#
echo "Get ECHAM water isotope fields"
echo " "
#
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,53 $INWISO wisoaprl
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,54 $INWISO wisoaprc
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,55 $INWISO wisoaprs
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,59 $INWISO wisoevap
$CDO -s -f nc -monmean               -selcode,51 $INWISO wisows
$CDO -s -f nc -monmean               -selcode,52 $INWISO wisosn
$CDO -s -f nc -monmean -mulc,2.628e6 -selcode,57 $INWISO wisorunoff
#
# calculate total precipitation
$CDO -s -f nc -chvar,wisoaprl,wisoaprt -chcode,53,50 -add wisoaprl wisoaprc wisoaprt
#
# calculate total precipitation - evaporation 
$CDO -s -f nc -chvar,wisoaprt,wisope -chcode,50,60 -add wisoaprt wisoevap wisope
#
#
# set ECHAM defaults fields to 0. if flux fields (reservoirs) are less than 0.05 mm/month (0.05 mm)
#
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 aprt aprt dummy; mv dummy aprt
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 aprl aprl dummy; mv dummy aprl
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 aprc aprc dummy; mv dummy aprc
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 aprs aprs dummy; mv dummy aprs
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 evap evap dummy1; $CDO -s -f nc -setmisstoc,0. -ifthen -lec,-0.05 evap evap dummy2; $CDO -s -f nc -add dummy1 dummy2 evap; rm dummy1 dummy2
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05 pe   pe   dummy1; $CDO -s -f nc -setmisstoc,0. -ifthen -lec,-0.05 pe   pe   dummy2; $CDO -s -f nc -add dummy1 dummy2 pe  ; rm dummy1 dummy2
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,5.e-5 ws ws dummy; mv dummy ws
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,5.e-5 sn sn dummy; mv dummy sn
$CDO -s -f nc -setmisstoc,0. -ifthen -gec,0.05  runoff runoff dummy; mv dummy runoff
#
#change the dimension of atmospheric variables
for varn in aprt aprl aprc aprs evap pe ws sn runoff
do
       cp $varn ${varn}.tmp1
       cp $varn ${varn}.tmp2
    ncecat -u lev ${varn} ${varn}.tmp1 ${varn}.tmp2 ${varn}.x
    ncpdq -a time,lev ${varn}.x ${varn}.xx
       mv ${varn} ${varn}.3d
       cp ${varn}.xx ${varn}
    rm ${varn}.tmp1 ${varn}.tmp2 ${varn}.x ${varn}.xx
done
# set water isotope fields to 0. if ECHAM default fields (reservoirs) are zero
#
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. aprt wisoaprt dummy; mv dummy wisoaprt
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. aprl wisoaprl dummy; mv dummy wisoaprl
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. aprc wisoaprc dummy; mv dummy wisoaprc
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. aprs wisoaprs dummy; mv dummy wisoaprs
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. evap wisoevap dummy; mv dummy wisoevap
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. pe   wisope   dummy; mv dummy wisope
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. ws   wisows   dummy; mv dummy wisows
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. sn   wisosn   dummy; mv dummy wisosn
$CDO -s -f nc -setmisstoc,0. -ifthen -nec,0. runoff wisorunoff dummy; mv dummy wisorunoff
#
# calculate delta values of all water isotope fields (reference standard: SMOW) 
# - the SMOW values have to be stored in the file SMOW.FAC.nc (with the correct grid size & order of isotope values!)
#
echo "Calculate delta values of water isotope fields"
echo " "
#
#$CDO -s -f nc -chvar,wisoaprt,wisoaprt_d     -chcode,50,10 -mulc,1000 -subc,1. -div -div -divc,1000  wisoaprt   aprt   $SMOW wisoaprt_d
#$CDO -s -f nc -chvar,wisoaprl,wisoaprl_d     -chcode,53,13 -mulc,1000 -subc,1. -div -div -divc,1000  wisoaprl   aprl   $SMOW wisoaprl_d
#$CDO -s -f nc -chvar,wisoaprc,wisoaprc_d     -chcode,54,14 -mulc,1000 -subc,1. -div -div -divc,1000  wisoaprc   aprc   $SMOW wisoaprc_d
#$CDO -s -f nc -chvar,wisoaprs,wisoaprs_d     -chcode,55,15 -mulc,1000 -subc,1. -div -div -divc,1000  wisoaprs   aprs   $SMOW wisoaprs_d
#$CDO -s -f nc -chvar,wisoevap,wisoevap_d     -chcode,59,19 -mulc,1000 -subc,1. -div -div -divc,1000  wisoevap   evap   $SMOW wisoevap_d
#$CDO -s -f nc -chvar,wisope,wisope_d         -chcode,60,20 -mulc,1000 -subc,1. -div -div -divc,1000  wisope     pe     $SMOW wisope_d
#$CDO -s -f nc -chvar,wisows,wisows_d         -chcode,51,11 -mulc,1000 -subc,1. -div -div -divc,1000  wisows     ws     $SMOW wisows_d
#$CDO -s -f nc -chvar,wisosn,wisosn_d         -chcode,52,12 -mulc,1000 -subc,1. -div -div -divc,1000  wisosn     sn     $SMOW wisosn_d
#$CDO -s -f nc -chvar,wisorunoff,wisorunoff_d -chcode,57,17 -mulc,1000 -subc,1. -div -div -divc,1000  wisorunoff runoff $SMOW wisorunoff_d
#
$CDO -s -f nc -chvar,wisoaprt,wisoaprt_d     -chcode,50,10 -mulc,1000 -subc,1. -div -div wisoaprt   aprt   $SMOW wisoaprt_d
$CDO -s -f nc -chvar,wisoaprl,wisoaprl_d     -chcode,53,13 -mulc,1000 -subc,1. -div -div wisoaprl   aprl   $SMOW wisoaprl_d
$CDO -s -f nc -chvar,wisoaprc,wisoaprc_d     -chcode,54,14 -mulc,1000 -subc,1. -div -div wisoaprc   aprc   $SMOW wisoaprc_d
$CDO -s -f nc -chvar,wisoaprs,wisoaprs_d     -chcode,55,15 -mulc,1000 -subc,1. -div -div wisoaprs   aprs   $SMOW wisoaprs_d
$CDO -s -f nc -chvar,wisoevap,wisoevap_d     -chcode,59,19 -mulc,1000 -subc,1. -div -div wisoevap   evap   $SMOW wisoevap_d
$CDO -s -f nc -chvar,wisope,wisope_d         -chcode,60,20 -mulc,1000 -subc,1. -div -div wisope     pe     $SMOW wisope_d
$CDO -s -f nc -chvar,wisows,wisows_d         -chcode,51,11 -mulc,1000 -subc,1. -div -div wisows     ws     $SMOW wisows_d
$CDO -s -f nc -chvar,wisosn,wisosn_d         -chcode,52,12 -mulc,1000 -subc,1. -div -div wisosn     sn     $SMOW wisosn_d
$CDO -s -f nc -chvar,wisorunoff,wisorunoff_d -chcode,57,17 -mulc,1000 -subc,1. -div -div wisorunoff runoff $SMOW wisorunoff_d
#
#
for varn in aprt aprl aprc aprs evap pe ws sn runoff
do
    cp ${varn}.3d ${varn}
    rm ${varn}.3d
done
# merge all files together to output file & change day of all records from 30th to 15th of each month
#
echo "Merge all files and clean up"
echo " "
#
$CDO -s -f nc -t $TBL -merge \
   wisoaprt_d wisoaprl_d wisoaprc_d wisoaprs_d wisoevap_d wisope_d wisows_d wisosn_d wisorunoff_d \
   wisoaprt   wisoaprl   wisoaprc   wisoaprs   wisoevap   wisope   wisows   wisosn   wisorunoff   \
       aprt       aprl       aprc       aprs       evap       pe       ws       sn       runoff   \
   temp2 tsurf dummy
#
MONTH=`$CDO -s showmon $IN`
$CDO -s -f nc -setday,15 -setmon,`echo ${MONTH}` dummy $OUT
rm dummy
#
# clean up
#
rm wisoaprt_d wisoaprl_d wisoaprc_d wisoaprs_d wisoevap_d wisope_d wisows_d wisosn_d wisorunoff_d
rm wisoaprt   wisoaprl   wisoaprc   wisoaprs   wisoevap   wisope   wisows   wisosn   wisorunoff
rm     aprt       aprl       aprc       aprs       evap       pe       ws       sn       runoff
rm temp2 tsurf
#
   echo "*** CALCULATION DONE... ***"
   exit 0
#
